import { sayHello } from "./ajax";

console.log(sayHello("TypeScript"));
