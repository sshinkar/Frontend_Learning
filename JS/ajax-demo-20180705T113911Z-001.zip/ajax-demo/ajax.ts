export function sayHello(name: string) {
    return `Hello from ${name}`;
}